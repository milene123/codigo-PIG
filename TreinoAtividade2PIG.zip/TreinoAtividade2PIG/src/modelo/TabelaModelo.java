/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import bd.BancoDeDados;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Borges
 */
public class TabelaModelo extends AbstractTableModel{
    
    @Override
    public int getRowCount() {
        return BancoDeDados.getPessoas().size();
    }

    @Override
    public int getColumnCount() {
        return 3;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Pessoa pessoa = BancoDeDados.getPessoas().get(rowIndex);
        switch(columnIndex){
            case 0: return pessoa.getNome();
            case 1: return nomeSexo(pessoa.getSexo());
            case 2: return pessoa.getCidade().toString();
        }
        return null;
    }
    
    @Override
    public String getColumnName(int coluna){
        switch(coluna){
            case 0: return "Nome";
            case 1: return "Sexo";
            case 2: return "Cidade";
            default:return super.getColumnName(coluna);
        }
    }
    
    private String nomeSexo(char sexo){
        if (sexo=='M')
            return "Masculino";
        else
            return "Feminino";
    }
}
