/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.util.ArrayList;

/**
 *
 * @author Everton
 */
public class Pessoa {
    private String nome;
    private String endereco;
    private String telefone;
    private Cidade cidade;
    private char sexo;
    private ArrayList<Interesse> interesses;

    public Pessoa() {
    }

    public Pessoa(String nome, String endereco, String telefone, Cidade cidade, char sexo, ArrayList<Interesse> interesses) {
        this.nome = nome;
        this.endereco = endereco;
        this.telefone = telefone;
        this.cidade = cidade;
        this.sexo = sexo;
        this.interesses = interesses;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public Cidade getCidade() {
        return cidade;
    }

    public void setCidade(Cidade cidade) {
        this.cidade = cidade;
    }

    public char getSexo() {
        return sexo;
    }

    public void setSexo(char sexo) {
        this.sexo = sexo;
    }

    public ArrayList<Interesse> getInteresses() {
        return interesses;
    }

    public void setInteresses(ArrayList<Interesse> interesses) {
        this.interesses = interesses;
    }
    
    @Override
    public String toString(){
        return nome;
    }
}
