/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bd;

import java.util.ArrayList;
import modelo.Cidade;
import modelo.Estado;
import modelo.Interesse;
import modelo.Pais;
import modelo.Pessoa;

/**
 *
 * @author Everton
 */
public class BancoDeDados {
    private static ArrayList<Interesse> interesses = new ArrayList<>();
    private static ArrayList<Pessoa> pessoas = new ArrayList<>();
    private static ArrayList<Cidade> cidades = new ArrayList<>();
    
    static{
        preencherCidade();
        preencherInteresses();
        preencherPessoas();
    }
    
    public static ArrayList<Interesse> getInteresses() {
        return interesses;
    }

    public static ArrayList<Pessoa> getPessoas() {
        return pessoas;
    }

    public static ArrayList<Cidade> getCidades() {
        return cidades;
    }
    
    private static void preencherInteresses(){
        interesses.add(new Interesse("Livros"));
        interesses.add(new Interesse("Jogos"));
        interesses.add(new Interesse("Esportes"));
    }
    
    private static void preencherCidade(){
        cidades.add(new Cidade(null, new Estado(null, new Pais(null, null))));
        cidades.add(new Cidade("Manaus", new Estado("AM", new Pais("Brasil", "BR"))));
        cidades.add(new Cidade("Rio de Janeiro", new Estado("RJ", new Pais("Brasil", "BR"))));
        cidades.add(new Cidade("São Paulo", new Estado("SP", new Pais("Brasil", "BR"))));
    }
    
    private static void preencherPessoas(){
        ArrayList<Interesse> novosInteresses;
        pessoas.add(new Pessoa("Teste 1", "Rua 4", "1111-1111", cidades.get(1), 'M', BancoDeDados.getInteresses()));
        novosInteresses = new ArrayList<>();
        novosInteresses.add(BancoDeDados.interesses.get(0));
        pessoas.add(new Pessoa("Teste 2", "Rua 3", "2222-2222", cidades.get(2), 'F', novosInteresses));
        novosInteresses = new ArrayList<>();
        novosInteresses.add(BancoDeDados.interesses.get(1));
        pessoas.add(new Pessoa("Teste 3", "Rua 2", "3333-3333", cidades.get(1), 'F', novosInteresses));
        novosInteresses = new ArrayList<>();
        novosInteresses.add(BancoDeDados.interesses.get(2));
        pessoas.add(new Pessoa("Teste 4", "Rua 1", "4444-4444", cidades.get(3), 'M', novosInteresses));
    }
}
